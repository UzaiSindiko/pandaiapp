const Staff = require("./Staff")
const QRCode = require("./QRCode")
const School = require("./School")
const Attendance = require("./Attendance")

module.exports = {
  Staff,
  QRCode,
  School,
  Attendance,
}
